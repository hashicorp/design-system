---
name: theming-readiness-audit
description: "Audit existing components and style to determine which will not respond to the implementation of non-default themes or theme switching"
---

## Context

This skill provides instructions on creating an audit of an application's components and styling to determine what components or styles will not respond to the implementation of theme support from `@hashicorp/design-system`.

### Theming support

The `@hashicorp/design-system` package supports multiple themes for its components and styles. A consumer can set a given theme for their application and all components and tokens in the library will automatically update to the appropriate styles based on the active theme.

- All `Hds::` components automatically respond to theming
- All library tokens of the format `--hds` respond to theming
  - The only exception are `--hds-core-color` tokens which are core values and not intended to be used by consumers

## Goal

Produce an audit, in the form of an `.md` document, that documents the component styles, global styles, and component features that will need to be changed in order to be themable.

## Unthemable content

All of the following items will not respond to theming:

- Inline styles using the `ember-style-modifier` when they contain hard-coded values or non-`--hds` variables
- Hard-coded CSS values
- CSS variables without the `--hds` prefix tied to one of the CSS properties listed below
- CSS variables with the `--hds-core-color` prefix
  - These are internal tokens to the design system library and should not be used by consumers
- Sass variables not resolving to a `--hds` CSS variable

### CSS properties to watch

Only the following properties need to be reviewed according to the rules listed above.

- Color
  - `background`
  - `background-color`
  - `background-image`
  - `color`
  - `border`
  - `border-color`
  - `box-shadow`
  - `outline`
  - `outline-color`
  - `fill`
  - `stroke`
- Typography
  - `font`
  - `font-family`
  - `font-size`
  - `font-weight`
  - `line-height`
- Sizing
  - `border-radius`

### Styling to ignore

- CSS properties
  - Ignore all `height`, `width`, `padding`, `margin`, and `border-width`
  - Ignore when `none` or `transparent` is used as a hard-coded value for colors
  - Ignore when `border-radius` is set to 0
- Class usage
  - Do not review usage of any HDS helper classes on HTML elements of the format `.hds-`
- CSS and Sass variables
  - Ignore CSS or Sass variables which ultimately resolve to a CSS variable with the prefix `--hds`, unless it has the `--hds-core-color` prefix

## Procedure

1. Gather scope from user
  - Required inputs from user
    - Scope of review, what components and styles to review
    - Path to available components
    - Path to available styles
    - Location to create the audit results document (optional)
      - If not specified, the audit results document will be created within the current AI workflow or outputted as plain text in the chat.

2. Review CSS / SCSS files
  - For every `css` or `scss` file within scope, search for any unthemable styles as outlined above
  - Take note of the CSS selector attached to each unthemable style

3. Review component files
  - For every `gts`, `ts`, `js`, `hbs`, `css`, and `scss` file in scope for the components, search for any unthemable content as outlined above
  - Take note of which components contain unthemable content

4. Review usage of `--hds-core-color` CSS variables
  - For every unthemeable style found in the components or styles, review for possibility of being migrated to a semantic token.
    - Follow the "Core token review guide" below

5. Prepare for potential migration
  - For each unthemeable style that can be migrated to a semantic token, prepare a plan for updating the code to use the semantic token.

6. Create an audit document outlining the results found, following the format listed below

## Core token review guide

When reviewing if an `--hds-core-color` CSS variable can be replaced with a semantic token, follow these steps:

1. Identify the `--hds-core-color` variable being used, and what property is used for.
2. Check if the token can be replaced with a 1:1 alias semantic token from the `core-to-semantic-token-aliases.json` file.
  - See if there is a 1:1 mapping between the `--hds-core-color` variable and a semantic token in the `core-to-semantic-token-aliases.json` file.
  - If a 1:1 mapping exists, determine if the available semantic token is appropriate for the property being used.
    - Only use `foreground` tokens for text color
    - Only use `surface` tokens for background color
    - Only use `border` tokens for border color
    - Only use modifier tokens like `active`, `hover`, or `disabled` for interactive styles
3. Check if the token can be replaced with a suggested semantic token from the `core-to-semantic-token-suggestions.json` file.
  - If a 1:1 mapping does not exist review the suggested semantic token values in `core-to-semantic-token-suggestions.json` file.
    - Determine if any of the suggested semantic token values are appropriate for the property being used.
    - Note that these suggested changes will result in visual differences.
4. Determine if the unthemeable style can be migrated to a semantic token.
  - If a valid semantic token update is available mark it as a token that can be replaced.
  - If no valid semantic token update is available, mark it as a token that cannot be replaced.

## Audit format

Follow the structure below for the audit of the findings

### Overview

Summary of findings. Overall assessment of the level of content that is not themable

- Number of total issues
- Number of files with issues
- Percentage of files with issues out of the total number assessed

### Theme-readiness

#### Usage

If evaluating components, for components with issues, search through the entire application for their usage in other components and templates. Determine which components are used the most often, and thus the most high impact.

Only include the top 10 results
```markdown
| Component | Number of instances | Number of issues |
| --------- | ---------------- | ---------------- |
| card-container | 3 | 4 |
```

#### Number of issues

Provide a list of the top least theme-ready components or files

Only include the top 10 results
```markdown
| Component | Number of issues |
| --------- | ------------------- |
| card-container | 4 |
```

### HDS core token usage

Provide a summary of the usage of HDS core tokens within the audited files. Include the number of style issues where each core token is used and highlight any patterns or common issues.

Only include the top 10 results
```markdown
| Core token | Number of issues | Number of migratable instances |
| ---------- | ------------------ | ---------------------------- |
| --hds-core-color-neutral-600 | 5 | 2 |
| --hds-core-color-blue-200 | 3 | 1 |
```

#### Token migration

Provide a summary of the potential migration of unthemeable styles to semantic tokens. Include which tokens can be replaced with 1:1 alias semantic tokens, which can be replaced with suggested semantic tokens, and which cannot be replaced.

Include a general summary of how many can be directly migrated, how many require suggested semantic tokens, and how many cannot be replaced.

### Recommended remediation strategy

Based on all of the available findings, group them into similar areas and come up with a series of tasks that could be completed to fix the issues.

Order the steps based on perceived priority. Create an action plan for remediating the issues.

### Appendix

[Complete list of files with issues]

[Complete core color token usage]

[Complete core color migration table]
